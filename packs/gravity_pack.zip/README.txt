GRAVITY EPISODE PACK
Unzip inside your what-if-studio folder (it adds src/episodes/gravity/episode.json).

Contents
- src/episodes/gravity/episode.json  final: 15 script beats, 150 shots, 150 edit cues, 1 fx, science
- ep_head.json, shots_01..05.jsonl, build.py  sources. Edit shots, then run: python3 build.py
- narration_gravity.txt  the narration as plain text (805 words, about 5 min)

Next steps
1. python <skill>/scripts/voice.py gravity
2. python <skill>/scripts/plan.py gravity   (check cue forms and pace)

Known gaps
- 53 edit cues use words that repeat in the narration (chair, phone, Now, So...).
  All are in reading order. If plan.py needs an occurrence form, fix those lines.
- New sets to build with the room kit: street, sea, underwater, sky, cabin, space.
  New props: wall switch marked G, showerhead.
- Science marked TO VERIFY: air expanding (beat 7), ocean lifting (beat 9), planes climbing (beat 10),
  Sun time (beat 13). Soften those lines if they do not hold.
- 805 words, a little under the 850 target.
- Keys are rough. Check them on the storyboard step.
