// The registry: add each new episode here (one import, one entry).
import { rewind } from './rewind';
import { copyPaste } from './copy-paste';
import { glimpse } from './glimpse';
import { glimpse60 } from './glimpse60';
import { promo } from './promo';
import { promo2 } from './promo2';
import { promo3 } from './promo3';

export const EPISODES = [rewind, copyPaste, glimpse, glimpse60, promo, promo2, promo3];