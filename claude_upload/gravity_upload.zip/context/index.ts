// The registry: add each new episode here (one import, one entry).
import { rewind } from './rewind';
import { copyPaste } from './copy-paste';
import { glimpse } from './glimpse';
import { glimpse60 } from './glimpse60';

export const EPISODES = [rewind, copyPaste, glimpse, glimpse60];